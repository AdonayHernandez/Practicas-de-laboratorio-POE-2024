﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer.Services;

namespace PresentationLayer.Forms
{
    public partial class StudentForm : Form
    {
        private readonly StudentService _studentService;
        private readonly CarrerService _carrerService;
        bool isEdit = false;
        public StudentForm()
        {
            InitializeComponent();
            _studentService = new StudentService();
            _carrerService = new CarrerService();

            loadStudentData();
            loadCbxCareers();
        }

        private void loadStudentData()
        {
            dgvStudent.DataSource = _studentService.GetAllStudent();
        }

        private void loadCbxCareers()
        {
            cbxCareerStudent.DataSource = _carrerService.GetAllCarrers();
            cbxCareerStudent.DisplayMember = "nameCareer";
            cbxCareerStudent.ValueMember = "idCareer";

        }
    }
}
